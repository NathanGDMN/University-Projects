package com.example.guessmaster;

import java.util.Scanner;
import androidx.appcompat.app.AppCompatActivity;
import java.lang.Math;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.*;
import android.content.DialogInterface;

public class GuessMaster extends AppCompatActivity{

	private TextView ticketsum;
	private ImageView entityImage;
	private TextView entityName;

	private EditText userIn;
	private String user_input;
	String answer;

	private Button guessButton;
	private Button btnclearContent;

	Politician trudeau = new Politician("Justin Trudeau", new Date("December", 25, 1971), 0.25, "Male", "Liberal");
	Singer dion = new Singer("Celine Dion", new Date("March", 30, 1968), 0.5, "Female", "La voix du bon Dieu", new Date("November", 6, 1981));
	Country usa = new Country("United States", new Date("July", 4, 1776), 0.1, "Washington D.C.");
	Person myCreator = new Person("Nathan Goodman", new Date("November", 22, 2002), 1, "Male");

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_guess_activity); //Change this later

		//TextView for total tickets
		ticketsum = (TextView) findViewById(R.id.ticket);

		//ImageView for entityImage
		entityImage = (ImageView) findViewById(R.id.entityImage);

		//TextView for entityName
		entityName = (TextView) findViewById(R.id.entityName);

		//EditText
		userIn = (EditText) findViewById(R.id.guessInput);

		//Specify the buttons in view
		guessButton = (Button) findViewById(R.id.btnGuess);
		btnclearContent = (Button) findViewById(R.id.btnClear);

		final GuessMaster gm = new GuessMaster();
		gm.addEntity(trudeau);
		gm.addEntity(dion);
		gm.addEntity(usa);
		gm.addEntity(myCreator);

		//OnClick Listener action for submit button
		guessButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				playGame();
			}
		});

		//OnClick Listener action for clear button
		btnclearContent.setOnClickListener(new OnClickListener(){
			@Override
			public void onClick(View v){
				changeEntity();
				Entity changedEntity = currentEntity.clone();
				while (currentEntity.equals(changedEntity)){
					changedEntity = entities[genRandomEntityIndex()].clone();
				}
				playGame(changedEntity);
			}
		});
	}

	/*--------------------------------------------------------------------------------------------*/
	/*------------------------------------------Game Code-----------------------------------------*/

	private int numberOfCandidateEntities = 0;
	private Entity[] entities = new Entity[10]; //10 is the maximum number of entities
	private Entity currentEntity;
	private boolean gameGoing;
	private int ticketCount = 0;

	/*----------Methods-----------*/
	public void addEntity(Entity entity) {
		entities[numberOfCandidateEntities] = entity;
		numberOfCandidateEntities += 1;
	}

	private void changeEntity(){
		userIn.setText(""); //Clear user input

	}

	private void ImageSetter(){
		if (currentEntity.getName().equals("Justin Trudeau")){
			entityImage.setImageResource(R.drawable.justint);
		}else if (currentEntity.getName().equals("Celine Dion")){
			entityImage.setImageResource(R.drawable.celidion);
		}else if (currentEntity.getName().equals("United States")){
			entityImage.setImageResource(R.drawable.usaflag);
		}
	}

	private void welcomeToGame(){
		//Welcome Alert
		AlertDialog.Builder welcomealert = new AlertDialog.Builder(GuessMaster.this);
		welcomealert.setTitle("GuessMaster_Game_v3");
		welcomealert.setMessage(currentEntity.welcomeMessage());
		welcomealert.setCancelable(false);

		welcomealert.setNegativeButton("START_GAME", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialop, int which) {
				Toast.makeText(getBaseContext(), "Game_is_starting ... Enjoy", Toast.LENGTH_SHORT).show();
			}
		});

		//Show Dialog
		AlertDialog dialog = welcomealert.create();
		dialog.show();
	}

	
	public void playGame(Entity entity) { //Game Code
		currentEntity = entity;

		//If image of entity to be guessed exists in drawable, the image of entity to be guessed is placed in the entityImage imageview
		ImageSetter();

		//Name of the entity to be guessed is placed in the entityName textview
		entityName.setText(entity.getName());

		//Get input from the EditText
		answer = userIn.getText().toString();
		answer = answer.replace("\n", "").replace("\r", "");
		Date guess = new Date(answer);

//		Date correct = entity.getDate();
//		Date guess = new Date(); //User Input

		if (guess.precedes(entity.getBorn())){
			//System.out.println("Incorrect. Try an a later date.");
			AlertDialog.Builder precedesalert = new AlertDialog.Builder(GuessMaster.this);
			precedesalert.setTitle("Incorrect");
			precedesalert.setMessage("Try a later date");
			precedesalert.setCancelable(false);
			precedesalert.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialogInterface, int i) {
					playGame(entity);
				}
			});
		} else if (entity.getBorn().precedes(guess)){
			//System.out.println("Incorrect. Try an a earlier date.");
			AlertDialog.Builder succeedalert = new AlertDialog.Builder(GuessMaster.this);
			succeedalert.setTitle("Incorrect");
			succeedalert.setMessage("Try a earlier date");
			succeedalert.setCancelable(false);
			succeedalert.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialogInterface, int i) {
					playGame(entity);
				}
			});
		} else{
			ticketCount += entity.getAwardedTicketNumber();
		}

		AlertDialog.Builder victoryalert = new AlertDialog.Builder(GuessMaster.this);
		victoryalert.setTitle("You won");
		victoryalert.setMessage("BINGO!" + entity.closingMessage());
		victoryalert.setCancelable(false);
		victoryalert.setNegativeButton("Continue", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialogInterface, int i) {
				//		System.out.println("You won " + entity.getAwardedTicketNumber() + " tickets this round.");
//		System.out.println("The total number of your tickets is " + ticketCount + ".");
//		System.out.println("*************************");
				Toast.makeText(getBaseContext(), "You won " + entity.getAwardedTicketNumber() + " tickets this round.", Toast.LENGTH_SHORT).show();
				ticketsum.setText("Total Tickets: " + ticketCount);
				playGame(); //My playGame() function from Assignment 2 does the same this as the ContinueGame() function in teh assignment outline
			}
		});
	}

	
	public void playGame(int entityIndex) {
		this.playGame(entities[entityIndex]);
	}
	
	public void playGame() {
		this.playGame(genRandomEntityIndex());
	}
	
	private int genRandomEntityIndex() { //Used in playGame()
		return (int) ((Math.random() * numberOfCandidateEntities));
	}
	
}
