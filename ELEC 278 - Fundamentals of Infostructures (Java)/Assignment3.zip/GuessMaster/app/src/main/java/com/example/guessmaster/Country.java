package com.example.guessmaster;

public class Country extends Entity {
	/*----------Instance Variables-----------*/
	private String capital;
	
	/*----------Constructors-----------*/
	public Country( )
    {
        super( );
        capital = "blank";
    }
	
	public Country(String entName, Date entBorn, double entDiff, String entCapital)
    {
        super(entName, entBorn, entDiff);
        capital = entCapital;
    }
	
	//Copy Constructor
	public Country (Country country) {
		super(country);
		this.capital = country.capital;
	}
	
	/*----------Methods-----------*/
	public String toString( ) {
		String countryS = 	super.toString() + 
							"Capital: " + capital + "\n";
		return countryS;
	}
	
	public String entityType( ) {
		return "This entity is a country!";
	}

	public Entity clone() {
		Country clone = new Country(this);
		return clone;
	}
}
