package com.example.guessmaster;

public abstract class Entity {
	/*----------Instance Variables-----------*/
	private String name;
	private Date born;
	private double difficulty;
	
	/*----------Constructors-----------*/
	public Entity( )
    {
        name = "January";
        born = new Date(1,1,1);
        difficulty = 0;
    }
	
	public Entity(String entName, Date entBorn, double entDiff)
    {
        name = entName;
        born = entBorn;
        difficulty = entDiff;
    }
	
	//Copy Constructor
	public Entity (Entity entity) {
		this.name = entity.name;
		this.born = entity.born;
		this.difficulty = entity.difficulty;
	}
	
	/*----------Methods-----------*/
	public String getName() {
		return name;
	}
	
	public Date getBorn() {
		return born;
	}
	
	public String toString( ) {
		String entityS = 	"Name: " + name + "\n" + 
							"Born at: " + born.toString() + "\n";
		return entityS;
	}
	
	public void printString( ) { 
		System.out.println(name + ", born on " + born.toString());
	}
	
	public boolean equals(Entity entity) {
		if (entity==null) {
			return false;
		}else {
			return (born.equals(entity.born) && (name.contentEquals(entity.name)));
		}
	}
	
	public int getAwardedTicketNumber( ) {
		int ticketNumber = (int) (difficulty * 100);
		return ticketNumber;
	}
	
	public abstract String entityType( );
	
	public abstract Entity clone( );
	
	public String welcomeMessage( ) {
		String welcome = "Welcome! Let's start the game! This entity is a " + this.entityType() + "!";
		return welcome;
	}
	
	public String closingMessage( ) {
		String closing = "Congratulations! The detailed information of the entity you guessed is: \n" + this.toString();
		return closing;
	}
	
}
