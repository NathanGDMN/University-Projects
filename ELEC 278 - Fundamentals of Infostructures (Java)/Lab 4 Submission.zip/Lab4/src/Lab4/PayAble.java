package Lab4;

public interface PayAble {
	public double amountToPay( );
	
	public void printPayment( );

}
