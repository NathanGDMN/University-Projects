module Lab4 {
}