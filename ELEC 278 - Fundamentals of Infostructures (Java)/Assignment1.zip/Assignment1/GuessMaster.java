package Assignment1;

import java.util.Scanner;

public class GuessMaster {
	
	private int numberOfCandidateEntities = 0;
	private Entity[] entities = new Entity[10]; //10 is the maximum number of entities
	
	
	/*----------Methods-----------*/
	public void addEntity(Entity entity) {
		entities[numberOfCandidateEntities] = entity;
		numberOfCandidateEntities += 1;
	}	
	
	public void playGame(Entity entity) { //Game Code
		System.out.println("Welcome to GuessMaster! Try and guess the birthdate of: " + entity.getName());
		
		Date correct = entity.getDate(); 
		Date guess = new Date(); //User Input
		
		
		do {
			guess.readInput();
			if (guess.equals(correct) == false){
				System.out.print("Incorrect. ");
				if (guess.precedes(correct) == false){
					System.out.println("Try an earlier date.");
				}else {
					System.out.println("Try a later date.");
				}
			}
		}while (correct.equals(guess) == false);
		
		System.out.println("BINGO. You got it!!");
		
		System.out.println("Do you want to play again? (Type yes to play again)");
		Scanner keyboard = new Scanner(System.in);
		String answer = keyboard.next( );
		
		if ((answer.toLowerCase()).equals("yes")) {
			this.playGame();
		}
		
		System.out.println("Thank you for playing GuessMaster!");
	}
	
	public void playGame(int entityIndex) {
		this.playGame(entities[entityIndex]);
	}
	
	public void playGame() {
		this.playGame(genRandomEntityIndex());
	}
	
	private int genRandomEntityIndex() { //Used in playGame()
		return (int) ((Math.random() * numberOfCandidateEntities));
	}
	
	
	//||||||||||MAIN METHOD |||||||||||
	public static void main(String[] args) {
			/*Initialization*/
			Entity trudeau = new Entity("Justin Trudeau", new Date("December", 25, 1971));
			Entity dion = new Entity("Celine Dion", new Date("March", 30, 1968));
			Entity usa = new Entity("United States", new Date("July", 4, 1776));
			
			GuessMaster gm = new GuessMaster();
			gm.addEntity(trudeau);
			gm.addEntity(dion);
			gm.addEntity(usa);
			
			/*--------------------*/
			
			gm.playGame();
			
	
	}
	
	
}
