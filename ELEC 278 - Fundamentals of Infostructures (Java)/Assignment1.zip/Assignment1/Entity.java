package Assignment1;

public class Entity {
	/*----------Instance Variables-----------*/
	private String name;
	private Date born;
	
	/*----------Constructors-----------*/
	public Entity( )
    {
        name = "January";
        born = new Date(1,1,1);
    }
	
	public Entity(String entName, Date entBorn)
    {
        name = entName;
        born = entBorn;
    }
	
	/*----------Methods-----------*/
	public String getName() {
		return name;
	}
	
	public Date getDate() {
		return born;
	}
	
	public void printString( ) { 
		System.out.println(name + ", born on " + born.toString());
	}
	
	public boolean equals(Entity entity) {
		if (entity==null) {
			return false;
		}else {
			return (born.equals(entity.born) && (name.contentEquals(entity.name)));
		}
	}
}
