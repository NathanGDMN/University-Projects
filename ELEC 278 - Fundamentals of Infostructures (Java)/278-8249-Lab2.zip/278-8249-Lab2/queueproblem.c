// queueproblem.c – Lab 02 – Nathan, Goodman

#include <stdio.h>
#include <stdlib.h>

int outputNum; // For print

struct item	{
    struct item		*next;
    int				value;
};
typedef struct item		Item;

// Queue implementation
struct queue {
    Item	*front;
    Item	*end;		// Pointers to front and end queue elements
    int		count;			// Number of items in queue
};
typedef struct queue	Queue;

struct queue *CreateQueue()
{
    struct queue *q = (struct queue*)malloc(sizeof(struct queue));
    q->front = NULL;
    q->end = NULL;
    q->count = 0;
    return q;
}

void qinsert (int n, Queue *q)
// Add value n to queue end of queue
{
    // Create node to hold value being added to queue
    Item	*pnew = (Item *)malloc(sizeof (struct item));
    //bool	result = false;
    if (pnew != NULL)	{
        pnew->value = n;
        pnew->next = NULL;
        // Make current last node point to new node
        if (q->end != NULL)	{
            q->end->next = pnew;
        }
        // and update queue's end pointer
        q->end = pnew;
        // If queue was empty, new node is also new front node
        if (q->front == NULL)	q->front = pnew;
        q->count++;
        //result = true;
    }
    //return result;
}//qinsert()

void qprint (Queue *q)
{
    Item	*pv;
    pv = q->front;
    while (pv != NULL)	{
        printf("%5d", pv->value);
        pv = pv->next;
        outputNum++;
        if (outputNum % 12 == 0) {
            putchar('\n');
        }
    }
}//qprint()

int main(int argc, char *argv[]) {

    Queue *queue1, *queue2, *queue3, *queue4;
    queue1 = CreateQueue();
    queue2 = CreateQueue();
    queue3 = CreateQueue();
    queue4 = CreateQueue();

    /* -------------------Get input------------------*/
    int tcount = 0;
    int i;
    int modulo4;

    printf("Input up to 400 integers, put a space or enter between each one.\n");
    printf("Input a negative integer to print.\n");


    while (tcount < 400) {
        scanf("%d", &i);

        if (i > -1) {
            printf("Recieved %d\n", i);
            modulo4 = i % 4;
            switch (modulo4) {
                case 0: //modulo4 = 0
                    qinsert(i, queue1);
                    printf("Queue 1\n", i);
                    break;
                case 1: //modulo4 = 1
                    qinsert(i, queue2);
                    printf("Queue 2\n", i);
                    break;
                case 2: //modulo4 = 2
                    qinsert(i, queue3);
                    printf("Queue 3\n", i);
                    break;
                case 3: //modulo4 = 3
                    qinsert(i, queue4);
                    printf("Queue 4\n", i);
                    break;
            }
            tcount = tcount + 1;
        } else { //Negative input
            tcount = 400; //Print Lists
        }
    }


    /*---------------Print Lists----------------*/

    //Queue 1
        qprint(queue1);
    //Queue 2
        qprint(queue2);
    //Queue 3
        qprint(queue3);
    //Queue 4
        qprint(queue4);


}