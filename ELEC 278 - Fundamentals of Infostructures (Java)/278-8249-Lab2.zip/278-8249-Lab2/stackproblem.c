// stackproblem.c – Lab 02 – Nathan, Goodman

#include <stdio.h>

int  top = -1;
char  stack [80];

int push (char n)
{
    if (top == 80)  return 0;
    stack[++top] = n;
}//push()

int main (void) {
    char ch = 0;

    printf("Input all characters.\n");
    printf("Press enter when you're done.\n");


    while (1 == 1) {
        scanf("%c", &ch);
        if (ch == '\n'){
            while (top != -1) {
            printf("%c", stack[top]);
            top = --top;
          }
          break;
        }
        push(ch);
    }
}