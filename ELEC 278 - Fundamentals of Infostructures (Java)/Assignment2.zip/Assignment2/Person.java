package Assignment2;

public class Person extends Entity {
	/*----------Instance Variables-----------*/
	private String gender;
	
	/*----------Constructors-----------*/
	public Person( )
    {
        super( );
        gender = "blank";
    }
	
	public Person(String entName, Date entBorn, double entDiff, String entGender)
    {
        super(entName, entBorn, entDiff);
        gender = entGender;
    }
	
	//Copy Constructor
	public Person (Person person) {
		super(person);
		this.gender = person.gender;
	}
	
	/*----------Methods-----------*/
	public String toString( ) {
		String personS = 	super.toString() + 
							"Gender: " + gender + "\n";
		return personS;
	}
	
	public String entityType( ) {
		return "This entity is a person!";
	}
	
	public Entity clone() {
		Person clone = new Person(this);
		return clone;
	}
}
