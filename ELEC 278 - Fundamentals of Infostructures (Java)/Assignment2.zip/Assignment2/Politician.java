package Assignment2;

public class Politician extends Person{
	/*----------Instance Variables-----------*/
	private String party;	
	
	/*----------Constructors-----------*/
	public Politician( )
    {
        super( );
        party = "blank";
    }
	
	public Politician(String entName, Date entBorn, double entDiff, String entGender, String entParty)
    {
        super(entName, entBorn, entDiff, entGender);
        party = entParty;
    }
	
	//Copy Constructor
	public Politician (Politician politician) {
		super(politician);
		this.party = politician.party;
	}
	
	/*----------Methods-----------*/
	public String toString( ) {
		String politicianS = 	super.toString() + 
								"Party: " + party + "\n";
		return politicianS;
	}
	
	public String entityType( ) {
		return "This entity is a politician!";
	}
	
	public Entity clone() {
		Politician clone = new Politician(this);
		return clone;
	}
}
