package Assignment2;

public class Singer extends Person{
	/*----------Instance Variables-----------*/
	private String debutAlbum;
	private Date debutAlbumReleaseDate;	
	
	/*----------Constructors-----------*/
	public Singer( )
    {
        super( );
        debutAlbum = "blank";
        debutAlbumReleaseDate = new Date(1,1,1);
    }
	
	public Singer(String entName, Date entBorn, double entDiff, String entGender, String entDebutAlbum, Date entDebutAlbumReleaseDate)
    {
        super(entName, entBorn, entDiff, entGender);
        debutAlbum = entDebutAlbum;
        debutAlbumReleaseDate = new Date(entDebutAlbumReleaseDate);
    }
	
	//Copy Constructor
	public Singer (Singer singer) {
		super(singer);
		this.debutAlbum = singer.debutAlbum;
		this.debutAlbumReleaseDate = singer.debutAlbumReleaseDate;
	}
	
	/*----------Methods-----------*/
	public String toString( ) {
		String singerS = 	super.toString() + 
							"Debut Album: " + debutAlbum + "\n" +
							"Release Date: " + debutAlbumReleaseDate.toString() + "\n";
		return singerS;
	}
	
	public String entityType( ) {
		return "This entity is a singer!";
	}
	
	public Entity clone() {
		Singer clone = new Singer(this);
		return clone;
	}
}
