package Assignment2;

import java.util.Scanner;

public class GuessMaster {
	
	private int numberOfCandidateEntities = 0;
	private Entity[] entities = new Entity[10]; //10 is the maximum number of entities
	private boolean gameGoing;
	private int ticketCount = 0;
	
	/*----------Methods-----------*/
	public void addEntity(Entity entity) {
		entities[numberOfCandidateEntities] = entity;
		numberOfCandidateEntities += 1;
	}	
	
	public void playGame(Entity entity) { //Game Code
		System.out.println("===================================");
		System.out.println();
		System.out.println("\t GuessMaster 2.0 ");
		System.out.println();
		System.out.println("===================================");
		
		gameGoing = true;
		
		while (gameGoing == true) {
		System.out.println("*************************");
		System.out.println("Welcome! Let's start the game! " + entity.entityType());
		System.out.println();
		
		System.out.println("Guess " + entity.getName() + "'s birthday");
		
		
		Date correct = entity.getDate(); 
		Date guess = new Date(); //User Input
		
		
		do {
			guess.readInput();
			
			if (guess.equals(correct) == false){
				System.out.print("Incorrect. ");
				if (guess.precedes(correct) == false){
					System.out.println("Try an earlier date.");
				}else {
					System.out.println("Try a later date.");
				}
			}
		}while (correct.equals(guess) == false);
		
		System.out.println("**********Bingo!**********");
		
		ticketCount += entity.getAwardedTicketNumber();
		
		System.out.println("You won " + entity.getAwardedTicketNumber() + " tickets this round.");
		System.out.println("The total number of your tickets is " + ticketCount + ".");
		System.out.println("*************************");
		
		System.out.println("Congratulations! The detailed information of the entity you guessed is: ");
		System.out.println(entity.toString());	
		
		//Change entity so next game you guess different
		entity = entities[genRandomEntityIndex()];
		}
	}
	
	public void playGame(int entityIndex) {
		this.playGame(entities[entityIndex]);
	}
	
	public void playGame() {
		this.playGame(genRandomEntityIndex());
	}
	
	private int genRandomEntityIndex() { //Used in playGame()
		return (int) ((Math.random() * numberOfCandidateEntities));
	}
	
	
	//||||||||||MAIN METHOD |||||||||||
	public static void main(String[] args) {
			/*Initialization*/
			Politician trudeau = new Politician("Justin Trudeau", new Date("December", 25, 1971), 0.25, "Male", "Liberal");
			Singer dion = new Singer("Celine Dion", new Date("March", 30, 1968), 0.5, "Female", "La voix du bon Dieu", new Date("November", 6, 1981));
			Country usa = new Country("United States", new Date("July", 4, 1776), 0.1, "Washington D.C.");
			Person myCreator = new Person("Nathan Goodman", new Date("November", 22, 2002), 1, "Male");
			
			GuessMaster gm = new GuessMaster();
			gm.addEntity(trudeau);
			gm.addEntity(dion);
			gm.addEntity(usa);
			gm.addEntity(myCreator);
			
			/*--------------------*/
			
			gm.playGame();
			
	
	}
	
	
}
